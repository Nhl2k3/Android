# Order Food

Update 11/01/2021: fix hầu hết các lỗi hiện tại trên ứng dụng

Hà Quốc Anh Kiệt 15110067 <br>
Lê Hoàng Giang 15110034

<hr>

Video demo: https://youtu.be/_l-Z5VpTzjM <br>
Nguồn: https://myclass.vn/lap-trinh-android-qua-ung-dung-orderfood-5380.html
